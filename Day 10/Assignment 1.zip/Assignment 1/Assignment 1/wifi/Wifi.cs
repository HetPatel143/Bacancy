﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment_1.Interface;

namespace Assignment_1.Wifi
{
    public class Wifi:ICommand
    {
        public void SendCommand(string command)
        {
            Console.WriteLine($"Command sent via WiFi: {command}");
        }
    }
}
