﻿using Assignment_1;
using Assignment_1.controller;
using Assignment_1.home_device;
using Assignment_1.Interface;
using System;

using Assignment_1.Wifi;

class Program
{
    public static void Main(string[] args)
    {
        ICommand ic1 = new Wifi();
        Control c1 = new Control(ic1);
        IDevice light = new Light();
        IDevice fan = new Fan();
        c1.TurnDeviceOn(light);
        c1.TurnDeviceOff(fan);
    }
}
