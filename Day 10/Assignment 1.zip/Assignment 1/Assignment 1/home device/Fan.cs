﻿using Assignment_1.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1.home_device
{
    public class Fan: IDevice
    {
        public void TurnOn()
        {
            Console.WriteLine("fan start");
        }
        public void TurnOff()
        {
            Console.WriteLine("fan stop");
        }
    }
}
