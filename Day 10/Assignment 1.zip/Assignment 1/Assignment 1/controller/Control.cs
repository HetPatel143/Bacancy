﻿using Assignment_1.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1.controller
{
        public class Control
        {
        private readonly ICommand CommandSend;

            public Control(ICommand commandSender)
            {
                CommandSend = commandSender;
            }

            public void TurnDeviceOn(IDevice device)
            {
                device.TurnOn();
                CommandSend.SendCommand("ON");
            }

            public void TurnDeviceOff(IDevice device)
            {
                device.TurnOff();
                CommandSend.SendCommand("OFF");
            }
        }
    }
